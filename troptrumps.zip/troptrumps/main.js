/*

Name = Top Trumps
Authors = Jordan, Anoop

*/

// create first three topics for the user to choose
class food{ 
    constructor (){
        //init variables
        this.option1 = 'calories'
        this.option2 = 'spice Level'
        this.option3 = 'Yum Scale'
        this.option4 = 'Price'
        this.option5 = 'size'
        this.calories = []
        this.spiceLevel = []
        this.yumScale = []
        this.price = []
        this.size = []
    }
    //filling in arrays
    generateArrays(){
        for(let i = 0; i < 30; i++){
            this.calories.push(Math.ceil(Math.random()*100))
            this.spiceLevel.push(Math.ceil(Math.random()*50))
            this.yumScale.push(Math.ceil(Math.random()*30))
            this.price.push(Math.ceil(Math.random()*250))
            this.size.push(Math.ceil(Math.random()*300))
        }
    }
}
class oldpeople{
    constructor(){
        //init variables
        this.option1 = 'smell'
        this.option2 = 'speed'
        this.option3 = 'age'
        this.option4 = 'height'
        this.option5 = 'number Of Wrinkles'
        this.smell = []
        this.speed = []
        this.age = []
        this.height = []
        this.numberOfWrinkles = []
    }
    //fill arrays
    generateArrays(){
        for(let i=0;i<30;i++){
            this.smell.push(Math.ceil(Math.random()*100))
            this.speed.push(Math.ceil(Math.random()*50))
            this.age.push(Math.ceil(Math.random()*30))
            this.height.push(Math.ceil(Math.random()*250))
            this.numberOfWrinkles.push(Math.ceil(Math.random()*300))
        }
    }
}
class countries{
    constructor(){
        //init variables
        this.option1 = 'population'
        this.option2 = 'size'
        this.option3 = 'temperature'
        this.option4 = 'citizen happiness'
        this.option5 = 'wealth'
        this.population = []
        this.size = []
        this.temperature = []
        this.citizenHappiness = []
        this.wealth = []
    }
    //filling arrays
    generateArrays (){
        for(let i=0;i<30;i++){
            this.population.push(Math.ceil(Math.random()*100))
            this.size.push(Math.ceil(Math.random()*50))
            this.temperature.push(Math.ceil(Math.random()*30))
            this.citizenHappiness.push(Math.ceil(Math.random()*250))
            this.wealth.push(Math.ceil(Math.random()*300))
        }
    }
}

// setting up global variables for different options.
let option1name = ''
let option2name = ''
let option3name = ''
let option4name = ''
let option5name = ''
let option1 = []
let option2 = []
let option3 = []
let option4 = []
let option5 = []
var player1score = 0;
var player2score = 0;
var count = 1;

//removes the first 2 indexes from the front of the array
function removeCards(arr){
    arr = arr.reverse()
    arr.pop()
    arr.pop()
    arr.reverse()
}

//main game loop
function game(){
    for(i=0;i<30;i++){
        if(count % 2 !== 0){ //player one 
            a = prompt('player 1 picks a option ' +option1name +': ' +option1[i] +' ' +option2name +': ' +option2[i] +' ' +option3name +': ' +option3[i] +' ' +option4name +': ' +option4[i] +' ' +option5name +': ' +option5[i] +' player 1 score '+player1score +' player 2 score' +player2score) 
            switch(a){
                case '1':
                    if(option1[i] > option1[i+1]){
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                    }else{
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                        count ++
                    }
                    break;
                case '2':
                    if(option2[i] > option2[i+1]){
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                    }else{
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                        couunt ++
                        }
                    break;
                case '3':
                    if(option3[i] > option3[i+1]){
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                    }else{
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                        count ++
                        }
                    break;
                case '4':
                    if(option4[i] > option4[i+1]){
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                    }else{
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                        count ++
                        }
                    break;
                case '5':
                    if(option5[i] > option5[i+1]){
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                    }else{
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                        count ++
                        }
                    break;
            }
        }else if(count % 2 === 0){ // player 2
            a = prompt('player 2 picks a option Option1: '+ option1name + " " +option1[i] +' Option2: ' + option2name + " " +option2[i] +' Option3: ' + option3name + " " +option3[i] +' option4: ' + option4name + " " + option4[i] +' Option5: ' + option5name + " " +option5[i] + 'Player1 score: ' +player1score +'player2 score: ' +player2score)
            switch(a){
                case '1':
                    if(option1[i] > option1[i+1]){
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                    }else{
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                        count ++
                    }
                    break;
                case '2':
                    if(option2[i] > option2[i+1]){
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                    }else{
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                        count ++
                        }
                    break;
                case '3':
                    if(option3[i] > option3[i+1]){
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                    }else{
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                        count ++
                        }
                    break;
                case '4':
                    if(option4[i] > option4[i+1]){
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                    }else{
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                        count ++
                        }
                    break;
                case '5':
                    if(option5[i] > option5[i+1]){
                        player2score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player2 Wins')
                    }else{
                        player1score += 1;
                        removeCards(option1)
                        removeCards(option2)
                        removeCards(option3)
                        removeCards(option4)
                        removeCards(option5)
                        alert('player1 Wins')
                        count ++
                        }
                    break;
            }
        }
    }
    if(player1score > player2score){
        alert('Player 1 Wins the game')
    }else{
        alert('player 2 wins the game')
    }
}

//when button pressed this function will run
function start(){
    input = prompt('what topic do you want? Food, Old people, countries' )
    switch(input){
        case ('food'):
            var x = new food()
            x.generateArrays()
            option1 = x.calories
            option2 = x.spiceLevel
            option3 = x.yumScale
            option4 = x.price
            option5 = x.size
            option1name = x.option1
            option2name = x.option2
            option3name = x.option3
            option4name = x.option4
            option5name = x.option5
            game()
            break;
        case ('old people' || 'oldpeople'):
            var x = new oldpeople()
            x.generateArrays()
            option1 = x.smell
            option2 = x.speed
            option3 = x.age
            option4 = x.height
            option5 = x.numberOfWrinkles
            option1name = x.option1
            option2name = x.option2
            option3name = x.option3
            option4name = x.option4
            option5name = x.option5
            game()
            break;
        case 'countries':
            var x = new countries()
            x.generateArrays()
            option1 = x.population
            option2 = x.size
            option3 = x.temperature
            option4 = x.citizenHappiness
            option5 = x.wealth
            option1name = x.option1
            option2name = x.option2
            option3name = x.option3
            option4name = x.option4
            option5name = x.option5
            game()
            break;
        default:
            alert('not a topic')
    }
}